Drop Database IF EXISTS CaseStudy cascade;
create database CaseStudy;
use CaseStudy;
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;

Drop table if exists branch;
Drop table if exists branch_dynamic;

--1) External table for Branch

CREATE EXTERNAL TABLE Branch(
        Branch_Code int, 
        Branch_Name STRING,
        Branch_Phone STRING,
        Branch_State String,
        Branch_City String,
        Last_Updated Timestamp,
        Branch_Zip int)

    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY ','
    STORED AS TEXTFILE
    location '/user/Credit_Card_System/Branch';

--1/2) Internal table for Branch


drop table Branch_dynamic;
CREATE TABLE Branch_dynamic
(       
        Branch_Code int, 
        Branch_Name STRING,
        Branch_Phone STRING,
        Branch_City String,
        Last_Updated Timestamp,
        Branch_Zip int
) 
PARTITIONED BY(Branch_State String)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' 
ESCAPED BY '"' LINES TERMINATED BY '\n' 
STORED AS textfile
LOCATION "/user/Partition/Branch_2";

INSERT OVERWRITE TABLE Branch_dynamic
PARTITION (Branch_State)
SELECT Branch_Code,Branch_Name,Branch_City,Branch_Zip,Branch_Phone,Last_Updated,Branch_State
FROM branch;


--2) External Table for Customer


CREATE EXTERNAL TABLE Customer(
        
CUST_SSN int,
FIRST_NAME String,
MIDDLE_NAME String,
LAST_NAME String,
CREDIT_CARD_NO String,
CUST_STREET String,
CUST_CITY String,
CUST_STATE String,
CUST_COUNTRY String,
CUST_ZIP String,
CUST_PHONE String,
CUST_EMAIL String,
LAST_UPDATED TIMESTAMP)

    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY ','
    STORED AS TEXTFILE
    location '/user/Credit_Card_System/customer';



--3) External Table for Time

CREATE EXTERNAL TABLE Time(
        
TIMEID String,
DAY int,
MONTH int,
QUARTER String,
YEAR STRING,
TRANSACTION_ID int)

    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY ','
    STORED AS TEXTFILE
    location '/user/Credit_Card_System/Time';


--4) External Table for Creditcard

CREATE EXTERNAL TABLE Creditcard(
        
TRANSACTION_ID int,
CREDIT_CARD_NO String,
CUST_SSN int,
BRANCH_CODE int,
TRANSACTION_TYPE String,
TRANSACTION_VALUE double,
TIMEID String)

    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY ','
    STORED AS TEXTFILE
    location '/user/Credit_Card_System/CreditCard';