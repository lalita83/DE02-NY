package resources;

public class myQuries {
public final static String totaByType = "select sum(transaction_value), count(*)" +
		"from CDW_SAPP_CREDITCARD " +
		"where TRANSACTION_TYPE = ? " +
		"GROUP by TRANSACTION_TYPE";

public final static String transactionbyzip = 
        "select cdwt.transaction_id,cdwt.transaction_type,cdwt.transaction_value,cdwt.day,cdwt.Month,cdwt.Year " +
		",cdwt.credit_card_No,cdwt.Cust_SSN,cdwc.First_Name,cdwc.Last_Name from cdw_sapp_creditcard cdwt join cdw_sapp_customer cdwc "  + 
		"on (cdwt.CUST_SSN=cdwc.SSN) " + 
		"where cdwc.cust_zip = ? AND cdwt.MONTH = ? AND cdwt.year=? " + 
		"Order by cdwt.day desc ";


public final static String totalbystate = "select cdwt.BRANCH_CODE,count(transaction_value), sum(transaction_value)"+
         "from cdw_sapp_creditcard cdwt\r\n" + 
		"join cdw_sapp_branch cdwb  on (cdwt.BRANCH_CODE=cdwb.BRANCH_CODE)\r\n" + 
		"where BRANCH_STATE = ? " + 
		"group by BRANCH_STATE";


public final static String getcustomerbySSN = "Select * from cdw_sapp_customer where ssn = ?";

public final static String Modifycustomer =  "update cdw_sapp_customer " +
		"set FIRST_NAME = ?, MIDDLE_NAME = ?, LAST_NAME = ? ," +
		"APT_NO = ?,STREET_NAME = ?, CUST_CITY = ?, CUST_STATE = ? ," +
		"CUST_COUNTRY = ?,CUST_ZIP= ?,CUST_PHONE = ?,CUST_EMAIL = ? " +
		"where  SSN = ? AND CREDIT_CARD_NO = ? ";
		

public static String getmonthlybill = "select transaction_id,transaction_type," +
		"transaction_value,CREDIT_CARD_NO,cust_ssn,branch_code from cdw_sapp_creditcard " + 
		"where CREDIT_CARD_NO=? AND month=? AND year=?";


public static String getmonthlybillbydate = "select transaction_id,transaction_type,transaction_value,credit_card_no,cust_ssn,branch_code, " + 
		" DATE(concat(YEAR,\"-\",MONTH, \"-\",DAY)) " + 
		"from cdw_sapp_creditcard\r\n" + 
		"where CREDIT_CARD_NO= ? " + 
		"and  DATE(concat(YEAR,'-',MONTH, '-',DAY)) between ? AND ? " + 
		"order by year,month,day desc";

}