package dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Transaction;
import resources.myQuries;

public class TransactionDao extends dbconnection_abstract {
	
 public Transaction gettotalbyType(String type) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException
 {
	 myconnection();
	 ps = con.prepareStatement(myQuries.totaByType);
		ps.setString(1, type);
		rs = ps.executeQuery();
		Transaction t = new Transaction();
		if(rs.next())
		{
			t.setValue(rs.getInt(1));
			t.setCount(rs.getInt(2));
			return t;  }		
		return null;
 }
 public List<Transaction> gettransactionbyzip(String Zip,int Mon,int Year) throws SQLException, InstantiationException, IllegalAccessException, 
 ClassNotFoundException, IOException
 {
	 List<Transaction> transactions = new ArrayList<Transaction>();
	 myconnection();
	 String sql = myQuries.transactionbyzip;
	 ps=con.prepareStatement(sql);
	 ps.setString(1, Zip);
	 ps.setInt(2, Mon);
	 ps.setInt(3, Year);
	 rs = ps.executeQuery();

  	        while(rs.next()) 
	        {

	            Transaction t = new Transaction();
	            t.setDay(rs.getInt(4));
	            t.setMonth(rs.getInt(5));
	            t.setYear(rs.getInt(6));
	            t.setSsn(rs.getInt(8));
                t.settransid(rs.getInt(1));   
	            t.setCardNo(rs.getString(7));
	            t.setValue(rs.getInt(3));
	            t.setType(rs.getString(2));
	            t.setfname(rs.getString(9));
	            t.setlname(rs.getString(10));
	            transactions.add(t);
           
	        }

	        return transactions;

  
 }
 
 public Transaction getTotalByState(String type) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException
 {
	 myconnection();
	 ps = con.prepareStatement(myQuries.totalbystate);
		ps.setString(1, type);
		rs = ps.executeQuery();
		Transaction t = new Transaction();
		if(rs.next())
		{
			t.setBranchCode(rs.getInt(1));
			t.setValue(rs.getInt(2));
			t.setCount(rs.getInt(3));
			
			return t;  
			}		
		return null;
 }
}