package dao;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import resources.myQuries;

import model.Customer;
import model.Transaction;

public class CustomerDao extends dbconnection_abstract{
	public List<Customer> getcustomerbySSN(int ssn) throws SQLException, InstantiationException, IllegalAccessException, 
	 ClassNotFoundException, IOException
	{
		Customer customer = null;
		List<Customer> customers = new ArrayList<>();
		myconnection();
		String sql = myQuries.getcustomerbySSN;
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1,ssn);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				Customer c = new Customer();
				c.setfName(rs.getString(1));
		        c.setmName(rs.getString(2));
		        c.setlName(rs.getString(3));
		        c.setCreditCardNo(rs.getString(5));
		        c.setStreetname(rs.getString(7));
		        c.setCity(rs.getString(8));
		        c.setState(rs.getString(9));
		        c.setCountry(rs.getString(10));
		        c.setZip(rs.getString(11));
		        c.setPhone(rs.getInt(12));
		        c.setEmail(rs.getString(13));
		        customers.add(c);
		    }
		} catch (SQLException e) {
		    e.printStackTrace();

		}

		return customers;
	}	
	public boolean Modifycustomer(String fName,String mName,String lName,int ssn,String credit,String aptNo,String streetname,String city,String state,String country,String zip,int phone,String email) throws SQLException, InstantiationException, IllegalAccessException, 
	 ClassNotFoundException, IOException
	 {
	       List<Customer> customers =  new ArrayList();
	       myconnection();
	        
	       String sql= myQuries.Modifycustomer;
	       try {
	    	   ps=con.prepareStatement(sql);
	    	   ps.setString(1, fName);
	    	   ps.setString(2, mName);
	    	   ps.setString(3, lName);
	    	   ps.setString(4, aptNo);
	    	   ps.setString(5, streetname);
	    	   ps.setString(6, city);
	    	   ps.setString(7, state);
	    	   ps.setString(8, country);
	    	   ps.setString(9, zip);
	    	   ps.setInt(10,phone);
	    	   ps.setString(11, email);
	    	   ps.setInt(12, ssn);
	    	   ps.setString(13, credit);
	    	   int k = ps.executeUpdate();
	    	   if(k==1) {
	    		   return true;
	    	   }
	       }catch(SQLException e) {
	    	   e.printStackTrace();
	    	   
	       }
	       return false;
	 }	
	public List<Map<String, String>>  getmonthlybill(String ccn, int month, int year) throws SQLException, InstantiationException,IllegalAccessException,ClassNotFoundException,IOException
	{

		
		List<Map<String, String>> customers =  new ArrayList();
	       myconnection();
	       String sql= myQuries.getmonthlybill;
	       try {
				ps = con.prepareStatement(sql);
				ps.setString(1,ccn);
				ps.setInt(2, month);
				ps.setInt(3, year);
				rs=ps.executeQuery();
				while(rs.next())
				{
					Map<String, String> bill = new HashMap<>();
					bill.put("Transaction ID", rs.getInt(1)+"");
					bill.put("Transaction Type", rs.getString(2));
					bill.put("Transaction Value", rs.getDouble(3)+"");
					bill.put("Credit Card Number", rs.getString(4));
					bill.put("Customer SSN", ""+rs.getInt(5));
					bill.put("Branch Code", ""+rs.getInt(6));
					
					customers.add(bill);
			    }
				return customers;
			} catch (SQLException e) {
			    e.printStackTrace();

			}

			return null;
	}

   public List<Map<String,String>> getmonthlybilldate(String ccn,String D1,String D2) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException{
	   {
		   List<Map<String,String>> customers =  new ArrayList();
		   myconnection();
		   String sql = myQuries.getmonthlybillbydate;
		   try {
			   ps=con.prepareStatement(sql);
			   ps.setString(1,ccn);
			   ps.setString(2,D1);
			   ps.setString(3, D2);
			   rs=ps.executeQuery();
			   while(rs.next())
			   {
				   Map<String, String> billbydate = new HashMap<>();
				   billbydate.put("Transaction ID",rs.getInt(1)+"");
				   billbydate.put("Transaction Type",rs.getString(2));
				   billbydate.put("Transaction Value", rs.getDouble(3)+"");
				   billbydate.put("Credit Card Number",rs.getString(4));
				   billbydate.put("Customer SSN",""+rs.getInt(5));
				   billbydate.put("Branch Code",""+rs.getInt(6));
				   customers.add(billbydate);
			   }
			   return customers;
		   }catch(SQLException e) {
			   e.printStackTrace();
		   }
		   return null;
	   }
	   
	   
   }
}
