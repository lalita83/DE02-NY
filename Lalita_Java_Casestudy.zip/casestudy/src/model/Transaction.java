package model;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import dao.dbconnection_abstract;

public class Transaction extends dbconnection_abstract{
	protected int day, month, year, ssn, branchCode,count,transid;
	protected double Value;
	
	protected String cardNo, type, fname,lname;
	
	
	public Transaction(int day, int month, int year, int ssn, int branchCode, int count, double value, int transid,
			String cardNo, String type, String fname, String lname) {
		this.day = day;
		this.month = month;
		this.year = year;
		this.ssn = ssn;
		//this.branchCode = branchCode;
		//this.count = count;
		this.Value = value;
		this.transid = transid;
		this.cardNo = cardNo;
		this.type = type;
		this.fname = fname;
		this.lname = lname;
	}

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public double getValue() {
		return Value;
	}

	public void setValue(double value) {
		this.Value=value;
	}

@Override
	public String toString() {
		return "Transaction [day=" + day + ", month=" + month + ", year=" + year + ", ssn=" + ssn + ", Value=" + Value + ", transid=" + transid + ", cardNo=" + cardNo
				+ ", type=" + type + ", fname=" + fname + ", lname=" + lname + "]";
	}

public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public int getBranchCode() {
	return branchCode;
	}

	public void setBranchCode(int branchCode) {
	this.branchCode = branchCode;
	}

	public int getCount() {
		return count;
	}
	public int gettransid() {
		return transid;
	}
	public void settransid(int transid) {
		this.transid=transid;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getfname() {
		return fname;
	}
    public void setfname(String fname)
    {
    	this.fname=fname;
    	
    }
    
    public String getlname() {
		return lname;
	}
    public void setlname(String lname)
    {
    	this.lname=lname;
    	
    }



	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

public void setDay(int day) {
	this.day = day;
}

public int getDay()
{
	return day;
}

public void setCount(int count) {
	// TODO Auto-generated method stub
	this.count  =  count;
}

}
