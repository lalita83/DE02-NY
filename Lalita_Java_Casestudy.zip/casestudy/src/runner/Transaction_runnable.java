package runner;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import dao.TransactionDao;
import dao.dbconnection_abstract;
import model.Transaction;
import resources.myQuries;

public class Transaction_runnable extends dbconnection_abstract{
	
	public void getTotalByType() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
			
		myconnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter transaction Type:");
		
		String type = sc.nextLine();
		
		TransactionDao td = new TransactionDao();
		Transaction mytransaction = td.gettotalbyType(type);
		System.out.println("Total number of transaction: " +mytransaction.getCount());
		System.out.println("Total value of transaction: " +mytransaction.getValue());
	}
		
	public void gettransactionbyzip() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
		myconnection();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter the zipcode");
		String Zip = sc.nextLine();
		
		System.out.println("Please enter month");
		int Mon= Integer.parseInt(sc.nextLine());
		
		System.out.println("Please enter year");
		int Year= Integer.parseInt(sc.nextLine());
		
		TransactionDao td = new TransactionDao();
		List<Transaction> mytransaction = td.gettransactionbyzip(Zip, Mon, Year);

		if(mytransaction !=null)

		{
			for(Transaction t : mytransaction)
			{
				System.out.println(t.toString());

			}
		}

		else System.out.println();
	}

	public void getTotalByState() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
			
		myconnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the state:");
		
		String state = sc.nextLine();
		
		TransactionDao td = new TransactionDao();
		Transaction mytransaction = td.getTotalByState(state);
		System.out.println("Total number of transaction: " +mytransaction.getCount());
		System.out.println("Total value of transaction: " +mytransaction.getValue());
		System.out.println("Branch Code is: " +mytransaction.getBranchCode());
	}
	}


	

