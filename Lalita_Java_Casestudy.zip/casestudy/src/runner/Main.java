package runner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.print.DocFlavor.INPUT_STREAM;

import dao.dbconnection_abstract;
import model.Customer;

public class Main  {

	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException {
		new Main();
	}
	
	public Main() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, IOException {
		Transaction_runnable t = new Transaction_runnable();
		Customer_runnable c = new Customer_runnable();
		
		int option = 0;
        Scanner input = new Scanner(System.in);
        
		
		do {
			
			System.out.println("Enter the option you want to choose to view details for the credit card[ Enter 0 to exit ]: ");
			
 		    option = input.nextInt();
			System.out.println(option);
			switch(option)
			{
						
	             case 0:
	              System.out.println("Quiting");
	              
		         break;			         
	             case 1: System.out.println("To view transaction by zip for a given month and year:");
	             t.gettransactionbyzip();
	             break;
	             
	             case 2: System.out.println("To view total number and values of transaction for a given type:");
	             t.getTotalByType();
	             break;
	             
	             case 3: System.out.println("To view total number values of transaction for a given state:");
	             t.getTotalByState();
	             break;
		    
	             case 4: System.out.println("To view customer details using SSN:");
	             c.getcustomerbySSN();
	             break;
	             
	             case 5:System.out.println("To modify customer details:");
	             c.Modifycustomer();
	             break;
	             
	             case 6:System.out.println("To view the monthly bill:");
	             c.getmonthlybill();
	             break;
	             
	             case 7:System.out.println("To view the monthly bill by date:");
	             c.getmonthlybillbydate();
		         break;
				         
			   
			}
			
			
			
		}while(option!=0) ;
		
		System.out.println("End of test");

	}

	
	
	
}
