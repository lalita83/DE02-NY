package runner;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import dao.CustomerDao;
import dao.dbconnection_abstract;
import model.Customer;
import model.Transaction;

public class Customer_runnable extends dbconnection_abstract{
	public void getcustomerbySSN() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
			
		myconnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the SSN of the desired customer:");
		int ssn= Integer.parseInt(sc.nextLine());
		CustomerDao cd = new CustomerDao();
		List<Customer> mycustomer = cd.getcustomerbySSN(ssn);
		if(mycustomer !=null)

		{
			for(Customer c : mycustomer)
			{
				System.out.println(c.toString());

			}
		}

		else System.out.println();
		
	}
	
	public void Modifycustomer() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{ 
		myconnection();
		  int phone = 0;
		String fName = "";
		String mName = "";
		String lName = "";
		String aptNo = "";
		String streetname = "";
		String city = "";
		String state = "";
		String country = "";
		String zip = "";
		String email = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the SSN of the customer");
		int ssn= Integer.parseInt(sc.nextLine());
		System.out.println("Please enter the credit card no of a customer");
		String credit = sc.nextLine();
		CustomerDao cd = new CustomerDao();
		List<Customer> mycustomer = cd.getcustomerbySSN(ssn);
		if(mycustomer !=null)

		{
			for(Customer c : mycustomer)
			{
				//System.out.println(c.toString());
				fName = c.getfName();
				mName=c.getmName();
				lName=c.getlName();
				credit=c.getCreditCardNo();
				aptNo=c.getAptNo();
				streetname=c.getStreetName();
				city=c.getCity();
				state=c.getState();
				country=c.getCountry();
				zip=c.getZip();
				email=c.getEmail();
				
			}
		}

		else System.out.println();

		loop: while(true) {
			System.out.println("Enter the field which you want to edit in the database [ Enter 0 to exit ]: ");
			int n = Integer.parseInt(sc.nextLine());
			switch(n) 
			{
			case 0:
				System.out.println("Quiting");
				break loop;
			            case 1: System.out.println("Enter the first name of the customer to be edited");
			            fName= sc.nextLine();
			            break;
			            case 2: System.out.println("Enter the middle name of the customer to be edited");
			            mName= sc.nextLine();
			            break;
			            case 3: System.out.println("Enter the last name of the customer to be edited");
			            lName=sc.nextLine();
			            break;
			            case 4: System.out.println("Enter the Apt No. of the customer to be edited");
			            aptNo=sc.nextLine();
			            break;
			            case 5: System.out.println("Enter the Street Name of the customer to be edited");
			            streetname=sc.nextLine();
			            break;
			            case 6:System.out.println("Enter the city of the customer to be edited");
			            city=sc.nextLine();
			            break;
			            case 7:System.out.println("Enter the state of the customer to be edited");
			            state=sc.nextLine();
			            break;
			            case 8:System.out.println("Enter the country of the customer to be edited");
			            country=sc.nextLine();
			            break;
			            case 9:System.out.println("Enter the zip of the customer to be edited");
			            zip=sc.nextLine();
			            break;
			            case 10:System.out.println("Enter the phone of the customer to be edited");
			            phone = Integer.parseInt(sc.nextLine());
			            break;
			            case 11:System.out.println("Enter the email of the customer to be edited");
			            email=sc.nextLine();
			            break;
			}    
			
			if(cd.Modifycustomer(fName,mName,lName,ssn,credit,aptNo,streetname,city,state,country,zip,phone,email))
			{
				System.out.println("Updated successfully!");
			
			}
			
			mycustomer = cd.getcustomerbySSN(ssn);
		
			if(mycustomer !=null)

			{
				for(Customer c : mycustomer)
				{
					System.out.println(c.toString());

				}
			}

		}
		
	}	
	public void getmonthlybill() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
		myconnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the credit card no of a customer");
		String credit_card_no = sc.nextLine();
		System.out.println("Please enter the month of the transaction");
		int month=sc.nextInt();
		System.out.println("Please enter the year of the transaction");
		int year=sc.nextInt();
		CustomerDao cd = new CustomerDao();
		List<Map<String, String>> mycustomer = cd.getmonthlybill(credit_card_no, month, year);
		
		for (Map<String, String> element : mycustomer) {
			for (Map.Entry<String, String> entry : element.entrySet()) {
			    String key = entry.getKey();
			    String value1 = entry.getValue();
			    
			    System.out.println(key + " : " + value1);
		
			}  

		}
			

}
	public void getmonthlybillbydate() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{ 
		myconnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the credit card no of a customer");
		String credit_card_no = sc.nextLine();
		System.out.println("Please enter the start date of the transaction");
		String date1 = sc.nextLine();
		System.out.println("Please enter the end date of the transaction");
		String date2= sc.nextLine();
		CustomerDao cd = new CustomerDao();
		List<Map<String, String>> mycustomer = cd.getmonthlybilldate(credit_card_no, date1, date2);
		for(Map<String,String> element : mycustomer) {
			for(Map.Entry<String,String> entry : element.entrySet()) {
				String Key = entry.getKey();
				String value2 = entry.getValue();
				System.out.println(Key + ":" + value2);
			}
		}

				
			}
			
		}
	
