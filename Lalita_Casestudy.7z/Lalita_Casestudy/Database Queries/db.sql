1) /* To    display    the    transactions    made    by customers  living  in  a  given  zipcode  for  a given month and year. Order by day in descending order */

use cdw_sapp;
select cdwt.transaction_id,cdwt.transaction_type,cdwt.transaction_value,cdwt.day,cdwt.Month,cdwt.YEAR,cdwt.credit_card_No,
cdwt.Cust_SSN,cdwc.First_Name,cdwc.Last_Name from cdw_sapp_creditcard cdwt join cdw_sapp_customer cdwc 
on(cdwt.CUST_SSN=cdwc.SSN)

where cdwc.cust_zip = '39120' AND cdwt.MONTH = '2' AND cdwt.year='2018'

Order by cdwt.day desc;

2) /* To display the number and total values of transactions for a given type */

select count(Transaction_value) as 'Count Transvalue', sum(transaction_value) as 'Sum Transvalue' 
from cdw_sapp_creditcard
where transaction_type = 'grocery'
group by transaction_type;

3) /* To display the number and total values of transactions for branches in a given state */

select cdwt.BRANCH_CODE,count(transaction_value) as 'Count Transavalue', sum(transaction_value) 
as 'Sum Transvalue' from cdw_sapp_creditcard cdwt
join cdw_sapp_branch cdwb  on (cdwt.BRANCH_CODE=cdwb.BRANCH_CODE)

where BRANCH_STATE = 'NJ'
group by BRANCH_STATE;


4) /* To  check  the  existing  account  details  of  a customer */
select * from cdw_sapp_customer;

5) /*  To modify the existing account details of a customer */ 
update cdw_sapp_customer
set first_name = 'rayan',Middle_Name = 'Jain',Last_Name = 'Jain',Apt_No = 208
,Street_name = 'Edgewater', CUST_CITY = 'Edgewater',CUST_STATE = 'NJ',CUST_COUNTRY = 'US',CUST_ZIP= 07020,CUST_PHONE = 123456,
CUST_EMAIL = 'abs'
where  ssn = 123456100 AND CREDIT_CARD_NO = 4210653310061055;

6) /* To generate  monthly  bill  for a credit  card number for a given month and year */

select * from cdw_sapp_creditcard 
where month = 02 AND year = 04/06/2018 AND CREDIT_CARD_NO = 4210653349028689;

7) /* To  display the transactions made by a customer between two dates. Order by year, month, and day in descending order */

select branch_code,
concat('(',SUBSTRING(BRANCH_PHONE, 1, 3),')' , '-' , SUBSTRING(BRANCH_PHONE, 4, 3) , '-' ,
 SUBSTRING(BRANCH_PHONE, 7, 4) )as BRANCHPHONE,
BRANCH_STATE,BRANCH_CITY,
CASE 
when Branch_Zip is null then '999999' 
else branch_zip end as Zipcode 
from cdw_sapp_branch;